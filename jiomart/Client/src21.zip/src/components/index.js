
export { All } from "./Nav/All";
export { Electronics } from "./Nav/Electronics";
export { Groceries } from "./Nav/Groceries";
export { HomeLifestyle } from "./Nav/HomeLifestyle";
export { Jewellery } from "./Nav/Jewellery";
export { Wellness } from "./Nav/Wellness";
export { Supplies} from "./Nav/Supplies";
export { Fashion} from "./Nav/Fashion";


 export { ScrollToTop } from './other/ScrollToTop';