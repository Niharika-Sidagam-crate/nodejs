

export const Supplies = () => {
  return (
    <div>Supplies</div>
  )
}
