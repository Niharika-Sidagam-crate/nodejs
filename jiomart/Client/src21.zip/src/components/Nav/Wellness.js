

export const Wellness = () => {
  return (
    <div>Wellness</div>
  )
}
