

export const Fashion = () => {
  return (
    <div>Fashion</div>
  )
}
