
export const Jewellery = () => {
  return (
    <div>Jewellery</div>
  )
}
