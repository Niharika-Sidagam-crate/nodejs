

export const Electronics = () => {
  return (
    <div>Electronics</div>
  )
}
