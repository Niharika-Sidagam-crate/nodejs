import React from 'react'

export const ProductList = () => {
  return (
    <div>ProductList</div>
  )
}
