export { HomePage } from "./Home/HomePage";

export { GroceriesList } from "./Products/GroceriesList";
export { ProductDetails } from "./ProductDetails";