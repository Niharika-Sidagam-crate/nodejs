import React from 'react'

export const Checkout = () => {
  return (
    <div>Checkout</div>
  )
}
