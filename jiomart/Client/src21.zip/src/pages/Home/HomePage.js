
import { Hero } from "./components/Hero";
import { Hero2 } from "./components/Hero2";
import { Home } from "./components/Home";

export const HomePage = () => {

   
  return (
    <div>
      {/* <Home /> */}
        <Hero />
        <Hero2 />

        <Hero />
    </div>
    
  )
}
